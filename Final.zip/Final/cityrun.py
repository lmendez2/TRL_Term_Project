import pygame
import time
import random
#set up
pygame.init()

# sounds for crash
crash_sound = pygame.mixer.Sound("no.ogg")
ouch_sound = pygame.mixer.Sound("ouch.wav")
hey_sound = pygame.mixer.Sound("hey.wav")
boo_sound = pygame.mixer.Sound("boo.wav")
aww_sound = pygame.mixer.Sound("aww.wav")
yikes_sound = pygame.mixer.Sound("yikes.wav")
cheer_sound = pygame.mixer.Sound("cheer.wav")
yay_sound = pygame.mixer.Sound("yay.ogg")
wow_sound = pygame.mixer.Sound("wow.ogg")

#define colors rgb
black = (0,0,0)
white = (255,255,255)
red = (255,0,0)
green = (0,255,0)
blue = (0,0,255)
brown = (163,115,51)

##images
man_img = pygame.image.load("man.png")
man_w = 85
old_img = pygame.image.load("oldm.png")
tour_img = pygame.image.load("tour.png")
home_img = pygame.image.load("home.png")
home_hover = pygame.image.load("homehover.png")
main_back = pygame.image.load("background.png")
busy_img = pygame.image.load("business_ppl.png")
ff1 = pygame.image.load("ff1.png")
ff2 = pygame.image.load("ff2.png")
ff3 = pygame.image.load("ff3.png")
ff4 = pygame.image.load("ff4.png")
ff5 = pygame.image.load("ff5.png")
ff6 = pygame.image.load("ff6.png")
ff7 = pygame.image.load("ff7.png")
ff8 = pygame.image.load("ff8.png")
ff9 = pygame.image.load("ff9.png")
ff10 = pygame.image.load("ff10.png")

##window size
screen_w = 1250
screen_h = 900
gamedisplay = pygame.display.set_mode((screen_w,screen_h))
##name of window
pygame.display.set_caption("City Run")
##time fps
clock = pygame.time.Clock()

##displays man
def man(x,y):
    gamedisplay.blit(man_img,(x,y))

"""Displays the different screens when called up"""
def homescreen(x,y):
    gamedisplay.blit(home_img,(0,0))

def homehover(x,y):
    gamedisplay.blit(home_hover,(0,0))

def main_background(x,y):
    gamedisplay.blit(main_back,(0,0))

##obstacles 
def obs_old(oldx,oldy,oldw,oldh):
    gamedisplay.blit(old_img,(oldx,oldy))

def obs_old2(oldx2,oldy2,oldw2,oldh2):
    gamedisplay.blit(old_img,(oldx2,oldy2))

def obs_tour(tourx,toury,tourw,tourh):
    gamedisplay.blit(tour_img,(tourx,toury))

def obs_tour2(tourx2,toury2,tourw2,tourh2):
    gamedisplay.blit(tour_img,(tourx2,toury2))

def obs_bus(busx,busy,busw,bush):
    gamedisplay.blit(busy_img,(busx,busy))

#keeps score
def points(count): 
    font = pygame.font.SysFont(None,50)
    text = font.render("Points: "+ str(count), True, brown)
    gamedisplay.blit(text,(550,100)) 

#textobjects
def text_objects(text,font):
    textsurface = font.render(text, True, brown)
    return textsurface, textsurface.get_rect()

##mesage
def messagedisplay(text):
    message = pygame.font.Font("freesansbold.ttf", 80)
    Textsurf, textrect = text_objects(text,message)
    textrect.center = ((screen_w/2), (screen_h/2))
    gamedisplay.blit(Textsurf,textrect)
    pygame.display.update()
    time.sleep(3)
    gameloop()

def play(x,y,w,h,action = None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed() 

    if x + w > mouse[0] > x and y + h > mouse [1] > y: 
        homehover(0,0)
        if click[0] == 1 and action !=None:
            # if action == "play":
            #     gameloop()
            action()
    else:
        homescreen(0,0)


##what happens when crash
def crash():
    crash_sounds = [crash_sound, ouch_sound, aww_sound, boo_sound, hey_sound, yikes_sound]
    playing = random.choice(crash_sounds)
    pygame.mixer.Sound.play(playing)
    fun_facts = [ff1,ff2,ff3,ff4,ff5,ff6,ff7,ff8,ff9,ff10]
    fun_fact_displayed = random.choice(fun_facts)
    gamedisplay.blit(fun_fact_displayed,(0,0))
    pygame.display.update()
    time.sleep(4)
    gameloop()

##start menu before game starts
def startmenu(): 
    intro = True
    while intro: 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit
                quit()

        play(447,650,403,90,gameloop)
        pygame.display.update()
        clock.tick(20)

#gameloop
def gameloop():
    x = (screen_w*.5)
    y = (screen_h*.7)
    x_change = 0
    oldx = random.randrange(0,screen_w)
    oldx2 = random.randrange(0,screen_w)
    tourx = random.randrange(0,screen_w)
    tourx2 = random.randrange(0,screen_w)
    busx = random.randrange(0,screen_w)
    busy = -250
    oldy = -300
    oldy2 = -300
    toury = -200
    toury2 = -200
    bus_speed = 6
    old_speed = 1
    old2_speed = 1
    tourspeed = 4
    tour_speed2 = 4
    bush = 252
    busw = 325
    oldw = 123
    oldw2 = 123
    oldh2 = 243
    oldh = 243
    tourw = 123
    tourw2 = 123
    tourh = 263
    tourh2 = 263

    dodged = 0

    ##stops the game 
    gameexit = False 

    while not gameexit:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            ##when the button is pressed
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x_change = -5
                elif event.key == pygame.K_RIGHT:
                    x_change = 5

            ##when the button is let go 
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    x_change = 0 
        main_background(0,0)
                

        x = x + x_change
    

        obs_old(oldx,oldy,oldh,oldw)
        obs_tour(tourx,toury,tourh,tourw)
        obs_bus(busx,busy,bush,busw)
        oldy = oldy + old_speed
        toury = toury + tourspeed
        busy = busy + bus_speed
        man(x,y)
        points(dodged)

        ##defining boundaries
        if x > screen_w - man_w or x < 0:
            crash()

        #new old man obstacles
        if oldy > screen_h: 
            oldy = 0 - oldh
            oldx = random.randrange(0,screen_w)
            dodged = dodged + 1
            old_speed = old_speed + 1
        
        #calculating if player crashed with old man 
        if y < oldy + oldh: 
            if (x > oldx and x < oldx + oldw) or (x + man_w > oldx and x + man_w < oldx + oldw):
                crash()
        
        #new tourist obstacles
        if toury > screen_h:
            toury = 0 - tourh
            tourx = random.randrange(0+tourw,screen_w-tourw)
            dodged = dodged + 2
            tourspeed = tourspeed + 1

        #calculate if player crashed with tourist
        if y < toury + tourh: 
            if (x > tourx and x < tourx + tourw) or (x + man_w > tourx and x + man_w < tourx + tourw):
                crash()
        
        #new business obstacles
        if busy > screen_h:
            busy = 0 - bush
            busx = random.randrange(0+busw,screen_w-busw)
            dodged = dodged + 3
            bus_speed = bus_speed + 1

        #calculate if player crashed with business
        if y < busy + bush: 
            if (x > busx and x < busx + busw) or (x + man_w > busx and x + man_w < busx + busw):
                crash()

        if dodged == 15 or dodged == 16 or dodged == 17:
            pygame.mixer.Sound.play(cheer_sound)
            #new old man obstacles

        if dodged > 15:
            if oldy2 > screen_h: 
                oldy2 = 0 - oldh2
                oldx2 = random.randrange(0,screen_w)
                dodged = dodged + 1
                old_speed2 = old_speed2 + 1
        
            #calculating if player crashed with old man 
            if y < oldy2 + oldh2: 
                if (x > oldx2 and x < oldx2 + oldw2) or (x + man_w > oldx2 and x + man_w < oldx2 + oldw2):
                    crash()

            oldy2 = oldy2 + old2_speed
            obs_old2(oldx2,oldy2,oldh2,oldw2)

        if dodged > 30: 
            if toury2 > screen_h: 
                toury2 = 0 - tourh2
                tourx2 = random.randrange(0,screen_w)
                dodged = dodged + 1
                tour_speed2 = tour_speed2 + 1
        
            #calculating if player crashed with old man 
            if y < toury2 + tourh2: 
                if (x > tourx2 and x < tourx2 + tourw2) or (x + man_w > tourx2 and x + man_w < tourx2 + tourw2):
                    crash()

            toury2 = toury2 + tour_speed2
            obs_tour2(tourx2,toury2,tourh2,tourw2)

        
        if dodged == 41 or dodged == 42:
            pygame.mixer.Sound.play(yay_sound)
        
        if dodged == 61 or dodged == 62:
            pygame.mixer.Sound.play(wow_sound)


        pygame.display.update()
        clock.tick(60)

startmenu()
gameloop()
pygame.quit()
quit()
    